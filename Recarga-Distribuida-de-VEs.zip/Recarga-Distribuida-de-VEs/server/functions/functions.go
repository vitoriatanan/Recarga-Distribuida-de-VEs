package functions

import (
	// "fmt"
	// "log"
	// "math/rand"
	// "net/http"
	// "os"
	// "time"

	mqtt "github.com/eclipse/paho.mqtt.golang"
	//"github.com/gin-gonic/gin"
)

type Server struct {
	serverName string
	serverLocation []int
	mqttClient mqtt.Client
}